package co.g2academy.mosewa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MosewaFinalProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
