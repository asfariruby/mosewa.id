package co.g2academy.mosewa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MosewaFinalProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MosewaFinalProjectApplication.class, args);
	}

}
