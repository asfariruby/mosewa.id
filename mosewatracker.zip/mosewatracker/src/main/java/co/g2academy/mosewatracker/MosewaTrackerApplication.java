package co.g2academy.mosewatracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MosewaTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MosewaTrackerApplication.class, args);
	}

}
